import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/attend")
public class attend extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	response.setContentType("text/html");
        String userType = request.getParameter("userType");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        password = hashPassword(password); // Assuming you have a method to hash the password

        // Database Connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/attendancemanagement";
        String dbUser = "root";
        String dbPassword = "vr13";
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            if ("Administrator".equals(userType)) {
                String query = "SELECT * FROM tbladmin WHERE emailAddress = ? AND password = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                    preparedStatement.setString(1, username);
                    preparedStatement.setString(2, password);

                    ResultSet rs = preparedStatement.executeQuery();

                    if (rs.next()) {
                        // Set session attributes
                        HttpSession session = request.getSession();
                        session.setAttribute("userId", rs.getInt("Id"));
                        session.setAttribute("firstName", rs.getString("firstName"));
                        session.setAttribute("lastName", rs.getString("lastName"));
                        session.setAttribute("emailAddress", rs.getString("emailAddress"));

                        response.sendRedirect("Admin/index.jsp"); // Change the path accordingly
                    } else {
                        response.getWriter().println("<div class='alert alert-danger' role='alert'>" +
                                "Invalid Username/Password!</div>");
                    }
                }
            } else if ("ClassTeacher".equals(userType)) {
                String query = "SELECT * FROM tblclassteacher WHERE emailAddress = ? AND password = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                    preparedStatement.setString(1, username);
                    preparedStatement.setString(2, password);

                    ResultSet rs = preparedStatement.executeQuery();

                    if (rs.next()) {
                        // Set session attributes
                        HttpSession session = request.getSession();
                        session.setAttribute("userId", rs.getInt("Id"));
                        session.setAttribute("firstName", rs.getString("firstName"));
                        session.setAttribute("lastName", rs.getString("lastName"));
                        session.setAttribute("emailAddress", rs.getString("emailAddress"));
                        session.setAttribute("classId", rs.getInt("classId"));
                        session.setAttribute("classArmId", rs.getInt("classArmId"));

                        response.sendRedirect("ClassTeacher/index.jsp"); // Change the path accordingly
                    } else {
                        response.getWriter().println("<div class='alert alert-danger' role='alert'>" +
                                "Invalid Username/Password!</div>");
                    }
                }
            }
            else {
                response.getWriter().println("<div class='alert alert-danger' role='alert'>" +
                        "Invalid Username/Password!</div>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        } catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
    }

    private String hashPassword(String password) {
        // Implement your password hashing logic here
        // For example, using MessageDigest
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }
}
